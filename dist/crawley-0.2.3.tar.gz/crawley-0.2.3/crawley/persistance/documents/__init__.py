from json import JSONDocument, session as json_session
from xml import XMLDocument, session as xml_session
from csv_doc import CSVDocument, session as csv_session

from meta import documents_entities

        
