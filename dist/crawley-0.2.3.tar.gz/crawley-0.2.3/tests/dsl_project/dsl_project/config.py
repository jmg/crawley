""" Crawlers configuration file """

start_urls = ["http://www.python.org/"]

max_depth = 0
