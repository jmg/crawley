------------------------------------------------------------------

Pythonic Crawling / Scraping Framework Built on Eventlet 

------------------------------------------------------------------

To install crawley run:

~$ python setup.py install

or from pip:

~$ pip install crawley

------------------------------------------------------------------

To start a new project run:

~$ crawley startproject [project_name]
~$ cd [project_name]

------------------------------------------------------------------

Finally, to crawl just run:

~$ crawley run

------------------------------------------------------------------

