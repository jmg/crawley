from compound_parser import CompoundParser

parsers = [CompoundParser]