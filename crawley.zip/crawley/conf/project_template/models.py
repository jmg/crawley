from crawley.persistance import Entity, UrlEntity, Field, Unicode

class %(project_name)sUrls(UrlEntity):    
    
    #this entity is intended for save urls
    pass
    
class %(project_name)sClass(Entity):
    
    #add your table fields here
    #example: text = Field(Unicode(255))
    pass
