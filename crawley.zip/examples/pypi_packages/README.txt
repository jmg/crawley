This is a dummy example that extracts data from the pypi's front page.
-> http://pypi.python.org/pypi

It parses the html page and takes data from the packages table storing
all in a sqlite database.

To run it just type inside the pypi directory:

~$ crawley run


